#include <Arduino.h>
#include <Wire.h>

const int buttonPin1 = PA1; // Pin für Taster 1 (LED 1 an Slave 1)
const int buttonPin2 = PA4; // Pin für Taster 2 (LED 2 an Slave 1)
const int buttonPin3 = PB0; // Pin für Taster 3 (LED 1 an Slave 2)
const int buttonPin4 = PC1; // Pin für Taster 4 (LED 2 an Slave 2)
const int buttonPin5 = PC0; // Pin für Taster 5 (alle LEDs an beiden Slaves einschalten)

const int slaveAddress1 = 0x10; // I2C-Adresse Slave 1
const int slaveAddress2 = 0x11; // I2C-Adresse Slave 2

// Funktion zum Umschalten einer LED
void toggleLED(int slaveAddress, int ledNumber) {
    Wire.beginTransmission(slaveAddress);
    Wire.write(ledNumber); // Befehl zum Umschalten der LED
    int result = Wire.endTransmission(); 

    // Überprüfe auf Fehler bei der Übertragung
    if (result != 0) {
        Serial.println("I2C-Fehler beim Senden");
    }
}

// Funktion zum Einschalten aller LEDs an einem Slave
void turnOnAllLEDs(int slaveAddress) {
    Wire.beginTransmission(slaveAddress);
    Wire.write(0x03); // Befehl zum Einschalten aller LEDs
    Wire.endTransmission();
    int result = Wire.endTransmission();

    // Überprüfe auf Fehler bei der Übertragung
    if (result != 0) {
        Serial.println("I2C-Fehler beim Senden");
    }
}

// Funktion zum Abfragen des LED-Status an einem Slave
int requestLEDStatus(int slaveAddress) {
    Wire.beginTransmission(slaveAddress);
    Wire.requestFrom(slaveAddress, 2); // Fordere 2 Bytes vom Slave an (Status der beiden LEDs)
    
    int status1 = -1;
    int status2 = -1;

    if (Wire.available() > 0) {
        status1 = Wire.read(); // Lese den Status der LED 1
    }

    if (Wire.available() > 0) {
        status2 = Wire.read(); // Lese den Status der LED 2
    }

    Wire.endTransmission(); // Übertragung beenden

    // Kombiniere den Status der LEDs zu einer Zahl (z.B. LED 1 im unteren Bit, LED 2 im höheren Bit)
    return (status2 << 1) | status1;
}

void setup() {
    Wire.begin(); // I2C initialisieren
    Serial.begin(9600); // UART für Kommunikation mit Computer

    // Pins für Taster als Eingänge konfigurieren
    pinMode(buttonPin1, INPUT_PULLDOWN);
    pinMode(buttonPin2, INPUT_PULLDOWN);
    pinMode(buttonPin3, INPUT_PULLDOWN);
    pinMode(buttonPin4, INPUT_PULLDOWN);
    pinMode(buttonPin5, INPUT_PULLDOWN);
}

void loop() {
    // Überprüfen der Tastereingänge und Senden der entsprechenden Befehle an die Slaves
    if (digitalRead(buttonPin1) == HIGH) {
        // LED 1 an Slave 1 umschalten
        toggleLED(slaveAddress1, 0x01);
        delay(200); // Entprellung
    }
    if (digitalRead(buttonPin2) == HIGH) {
        // LED 2 an Slave 1 umschalten
        toggleLED(slaveAddress1, 0x02);
        delay(200); // Entprellung
    }
    if (digitalRead(buttonPin3) == HIGH) {
        // LED 1 an Slave 2 umschalten
        toggleLED(slaveAddress2, 0x01);
        delay(200); // Entprellung
    }
    if (digitalRead(buttonPin4) == HIGH) {
        // LED 2 an Slave 2 umschalten
        toggleLED(slaveAddress2, 0x02);
        delay(200); // Entprellung
    }
    if (digitalRead(buttonPin5) == HIGH) {
        // Alle LEDs an beiden Slaves einschalten
        turnOnAllLEDs(slaveAddress1);
        turnOnAllLEDs(slaveAddress2);
        delay(200); // Entprellung
    }

    // Überprüfe, ob eine Tastatureingabe vorliegt
    if (Serial.available() > 0) {
        char key = Serial.read(); // Lese das Eingabedatum

        // Prüfe, ob die Taste 'A' oder 'a' gedrückt wurde
        if (key == 'A' || key == 'a') {
            // LED-Status der Slaves abfragen
            int status1 = requestLEDStatus(slaveAddress1);
            int status2 = requestLEDStatus(slaveAddress2);

            // Ausgabe des Status der LEDs
            
            Serial.print("Slave 1 - LED Status: ");
            Serial.print((status2 & 0x01) ? "LED-Gelb: ON, " : "LED-Gelb: OFF, ");
            Serial.println((status2 & 0x02) ? "LED-Gruen: ON" : "LED-Gruen: OFF");
            
            
            Serial.print("Slave 2 - LED Status: ");
            Serial.print((status1 & 0x01) ? "LED-Weiss: ON, " : "LED-Weiss: OFF, ");
            Serial.println((status1 & 0x02) ? "LED-Blau: ON" : "LED-Blau: OFF");


        }
    }
}
