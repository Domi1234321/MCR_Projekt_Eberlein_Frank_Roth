#include <Arduino.h>
#include <Wire.h>
 
const int ledPin1 = PA10; // Pin für LED 1
const int ledPin2 = PB3; // Pin für LED 2
bool ledState1 = false; // Status von LED 1
bool ledState2 = false; // Status von LED 2
 
// Deklariere die Funktionen receiveEvent und requestEvent vor ihrer Verwendung
void receiveEvent(int bytes);
void requestEvent();
 
void setup() {
    Wire.begin(0x11); // I2C initialisieren mit Slave-Adresse 0x11
    Wire.onReceive(receiveEvent);
    Wire.onRequest(requestEvent);
    pinMode(ledPin1, OUTPUT);
    pinMode(ledPin2, OUTPUT);
    Serial.begin(9600); // UART für Debugging
}
 
// Definiere die Funktion receiveEvent
void receiveEvent(int bytes) {
    // Empfangene Daten verarbeiten
    while (Wire.available() > 0) {
        int command = Wire.read();
        if (command == 0x01) {
            // LED 1 umschalten
            ledState1 = !ledState1;
            digitalWrite(ledPin1, ledState1 ? HIGH : LOW);
        } else if (command == 0x02) {
            // LED 2 umschalten
            ledState2 = !ledState2;
            digitalWrite(ledPin2, ledState2 ? HIGH : LOW);
        } else if (command == 0x03) {
            // Alle LEDs einschalten
            ledState1 = true;
            ledState2 = true;
            digitalWrite(ledPin1, HIGH);
            digitalWrite(ledPin2, HIGH);
        }
    }
}
 
// Definiere die Funktion requestEvent
void requestEvent() {
    // Master möchte Daten anfordern
    Wire.write(ledState1 ? 1 : 0); // Senden des Status von LED 1
    Wire.write(ledState2 ? 1 : 0); // Senden des Status von LED 2
}
 
void loop() {
    // Leerlaufschleife, kann für andere Aufgaben verwendet werden
}